<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use App\Models\Appoinment;
use Illuminate\Support\Facades\DB;
use Carbon\Carbon;

class HomeController extends Controller
{
    /**
     * Create a new controller instance.
     *
     * @return void
     */
    public function __construct()
    {
        $this->middleware('auth');
    }

    /**
     * Show the application dashboard.
     *
     * @return \Illuminate\Contracts\Support\Renderable
     */
    public function index()
    {

        $currentDate = Carbon::today();

        $appoinments =  DB::table('appoinments')
        ->select('appoinments.*', DB::raw('patients.name as patientname'),DB::raw('patients.id as patientid'))
        ->leftjoin('patients','appoinments.patient_id','=','patients.id')
        ->where('appoinments.status' , '=', '0')
        ->where('appoinments.date' , '=', $currentDate)
         ->where('patients.status' , '=', '0')
        ->get();
        return view('doctorhome', ['appoinments' => $appoinments]);

    }
    public function view_patient_details($id)
    {

        $diagnostic_categories =  DB::table('diagnostic_categories')
        ->select('diagnostic_categories.*')
        ->get();

        $patientDtl =  DB::table('patients')
        ->select('patients.*', DB::raw('titles.title as title'))
        ->leftjoin('titles','patients.title','=','titles.id')
        ->where('patients.id' , '=', $id)
        ->get();

        $investigationDel =  DB::table('investigation_details')
        ->select('investigation_details.*', DB::raw('diagnostic_categories.category_name as category_name'))
        ->leftjoin('diagnostic_categories','investigation_details.investigation_id','=','diagnostic_categories.id')
        ->where('investigation_details.id' , '=', $id)
        ->get();

        $drugs =  DB::table('drugs')
        ->select('drugs.*')
        ->where('drugs.status' , '=', '0')
        ->get();

        $medical_tests =  DB::table('medical_tests')
        ->select('medical_tests.*')
        ->where('medical_tests.status' , '=', '0')
        ->get();

        $names = DB::table('patients')->where('status', 0)->pluck('name', 'id');
        
        $currentDate = Carbon::today();

        $investigation_history =  DB::table('investigation_history')
        ->select('investigation_history.*')
        ->where('investigation_history.patient_id' , '=', $id)
        ->where('investigation_history.appointment_date' , '=', $currentDate)
        ->get();

        $reccomanded_opd_drugs =  DB::table('reccomanded_opd_drugs')
        ->select('reccomanded_opd_drugs.*')
        ->where('reccomanded_opd_drugs.patient_id' , '=', $id)
        ->where('reccomanded_opd_drugs.appointment_date' , '=', $currentDate)
        ->get();

        $reccomanded_outside_drugs =  DB::table('reccomanded_outside_drugs')
        ->select('reccomanded_outside_drugs.*')
        ->where('reccomanded_outside_drugs.patient_id' , '=', $id)
        ->where('reccomanded_outside_drugs.appointment_date' , '=', $currentDate)
        ->get();

        $reccomanded_medical_test =  DB::table('medical_test')
        ->select('medical_test.*')
        ->where('medical_test.patient_id' , '=', $id)
        ->where('medical_test.appointment_date' , '=', $currentDate)
        ->get();
        return view('patientdashboard',['diagnostic_categories' => $diagnostic_categories ,'patientDtl' => $patientDtl ,'drugs' => $drugs,'names' => $names,'medical_tests' => $medical_tests,'investigationDel'=>$investigationDel, 'investigation_history'=>$investigation_history, 'reccomanded_opd_drugs'=>$reccomanded_opd_drugs, 'reccomanded_outside_drugs'=>$reccomanded_outside_drugs, 'reccomanded_medical_test'=>$reccomanded_medical_test]);
    }


public function appointment_search(Request $request)
    {

        $mytime = Carbon::today();
        $currentDate = $mytime->format('Y-m-d');


        $appoinments = DB::table('appoinments')
        ->leftjoin('patients','appoinments.patient_id','=','patients.id');

            if (isset($request->keyword)) {
                $keyword = $request->keyword;
                $appoinments =$appoinments->orwhere("patients.nic", 'LIKE', '%' . $keyword . '%');
                $appoinments =$appoinments->orwhere("patients.family_name", 'LIKE', '%' . $keyword . '%');
                $appoinments =$appoinments->orwhere("patients.name", 'LIKE', '%' . $keyword . '%');
                $appoinments =$appoinments->orwhere("patients.mobile", 'LIKE', '%' . $keyword . '%');
                $appoinments =$appoinments->orwhere("patients.address", 'LIKE', '%' . $keyword . '%');
            }
        $appoinments = $appoinments->where("patients.status", "=", "0")
        ->select('appoinments.*', DB::raw('patients.name as patientname'),DB::raw('patients.id as patientid'))
        ->where('appoinments.status' , '=', '0')
        ->where('appoinments.date' , '=', $currentDate)
        ->where('patients.status' , '=', '0')
        ->orderBy('appoinments.date', 'DESC')->first();

        return view('doctorhome', ['appoinments' => $appoinments]);

    }
    
    public function homeview()
    {

        $currentDate = Carbon::today();
        $waiting_list =  DB::table('appoinments')
        ->select('appoinments.*')
        ->leftjoin('patients','appoinments.patient_id','=','patients.id')
        ->where('appoinments.status' , '=', "0")
        ->where('appoinments.date' , '=', $currentDate)
        ->where('patients.status' , '=', '0')
        ->get()
        ->count();


        $finished_list =  DB::table('appoinments')
    ->select('appoinments.*', DB::raw('patients.name as patientname'))
    ->leftjoin('patients','appoinments.patient_id','=','patients.id')
    ->where('appoinments.status' , '=', "1")
    ->where('appoinments.date' , '=', $currentDate)
    ->where('patients.status' , '=', '0')
    ->get()
    ->count();


    $patient_list = DB::table('patients')
            ->join('titles', 'titles.id', '=', 'patients.title')
            ->where("patients.status", "=", "0")
            ->select('patients.*','titles.title as title')
            ->get()
            ->count();

            $drugs_list =  DB::table('drugs')
            ->select('drugs.*')
            ->where('drugs.status' , '=', "0")
            ->get()
            ->count();


        return view('home', ['waiting_list' => $waiting_list , 'finished_list' => $finished_list , 'patient_list' => $patient_list , 'drugs_list' => $drugs_list]);

    }
    
    
}
