<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\MedicalTest;

class MedicalTestController extends Controller
{
    public function view()
    {
        return view('medicalTestAdd');

    }


    public function add(Request $request)
    {
		$data=[
                    'test_name' => $request->test_name
                ];
                MedicalTest::create($data);

                try {
                    return redirect()->back()->with('success', 'Medical Test Successfuly Saved ..!');

                } catch (Exception $e) {

                    return redirect()->back()->with('error', 'Medical Test Inserting Error ..!');
                }
}

    public function  medical_test_list()
    {
        $medical_test_list =  DB::table('medical_tests')
        ->select('medical_tests.*')
        ->where('medical_tests.status' , '=', "0")
        ->get();

        $medical_test_list_deleted =  DB::table('medical_tests')
        ->select('medical_tests.*')
        ->where('medical_tests.status' , '=', "1")
        ->get();

        return view('medicalTestList',['medical_test_list' => $medical_test_list , 'medical_test_list_deleted' => $medical_test_list_deleted]);
    }

    public function delete(Request $request){
        $medical_test = medicaltest::find($request->id);
        $medical_test->status='1';

        try {
            $medical_test->save();
            return redirect()->back()->with('success', 'medical_test Deleted ..!');

        } catch (Exception $e) {

            return redirect()->back()->with('error', 'medical_test Deleted Error ..!');
        }
    }

    public function active(Request $request){
        $medical_test = medicaltest::find($request->id);
        $medical_test->status='0';

        try {
            $medical_test->save();
            return redirect()->back()->with('success', 'medical_test Deleted ..!');

        } catch (Exception $e) {

            return redirect()->back()->with('error', 'medical_test Deleted Error ..!');
        }
    }

    public function medical_test_search(Request $request)
    {
        $medical_test_list = DB::table('medical_tests');

        if (isset($request->test_name)) {
            $test_name = $request->test_name;
            $medical_test_list =$medical_test_list->where("medical_tests.test_name", 'LIKE', '%' . $test_name . '%');
        }
        $medical_test_list = $medical_test_list->where("medical_tests.status", "=", "0")
            ->select('medical_tests.*')
            ->orderBy('medical_tests.test_name', 'asc')
            ->where('medical_tests.status' , '=', "0")
            ->get();


            $medical_test_list_deleted =  DB::table('medical_tests')
            ->select('medical_tests.*')
            ->orderBy('medical_tests.test_name', 'asc')
            ->where('medical_tests.status' , '=', "1")
            ->get();
            return view('medicalTestList',['medical_test_list' => $medical_test_list , 'medical_test_list_deleted' => $medical_test_list_deleted]);

    }

    public function edit($id)
    {

        $medical_tests =  DB::table('medical_tests')
        ->select('medical_tests.*')
        ->where('medical_tests.id' , '=', $id)
        ->get();
        return view('medicalTestEdit',['medical_tests' => $medical_tests]);
    }

    public function update(Request $request)

    {

        $medical_tests = medicaltest::find($request->id);
        $medical_tests->update([
        'test_name' => $request->test_name,
    ]);
    try {
        return redirect()->back()->with('success', 'Medical Test Successfuly Updated ..!');

    } catch (Exception $e) {

        return redirect()->back()->with('error', 'Medical Test Updated Error ..!');
    }
}

}
