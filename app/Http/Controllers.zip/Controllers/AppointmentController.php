<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Patients;
use App\Models\Appoinment;
use App\Models\InvestigationDetails;

use Carbon\Carbon;

class AppointmentController extends Controller
{
    public function view()
    {

        $patients =  DB::table('patients')
        ->select('patients.*')
        ->where('patients.status' , '=', '0')
        ->get();

        return view('appointmentAddView',['patients' => $patients]);

    }

    public function  appointment_list()
    {
        $currentDate = Carbon::today();

        $appointment_list =  DB::table('appoinments')
        ->select('appoinments.*', DB::raw('patients.name as patientname'))
        ->leftjoin('patients','appoinments.patient_id','=','patients.id')
        ->where('appoinments.date' , '=', $currentDate)
        ->where('patients.status' , '=', '0')
        ->get();

        return view('appointmentListView',['appointment_list' => $appointment_list]);
    }

       public function add($id)
    {
        $currentDate = Carbon::today();
        $app_no =  DB::table('appoinments')
        ->select('appoinments.appointment_no')
        ->where('appoinments.date' , '=', $currentDate)
        ->orderBy('appoinments.appointment_no', 'DESC')->first();


        if ($app_no !== null) {
            $val = $app_no->appointment_no;
            $appointment_no = $val + 1;
        }else{
            $appointment_no = 1;
        }

		$data=[
                    'appointment_no' => $appointment_no,
                    'patient_id' => $id,
                    'date' => $currentDate,
                    'appdateTime' => $currentDate,
                    'status' => '0',
                ];
                Appoinment::create($data);

                try {
                    return redirect()->back()->with('success', 'Appointment Successfuly Saved ..!');

                } catch (Exception $e) {

                    return redirect()->back()->with('error', 'Appointment Inserting Error ..!');
                }
}

public function  waitingList()
{
    $currentDate = Carbon::today();

    $waiting_list =  DB::table('appoinments')
    ->select('appoinments.*', DB::raw('patients.name as patientname'))
    ->leftjoin('patients','appoinments.patient_id','=','patients.id')
    ->where('appoinments.status' , '=', "0")
    ->where('appoinments.date' , '=', $currentDate)
    ->where('patients.status' , '=', '0')
    ->get();

    return view('appointmentWaitingList',['waiting_list' => $waiting_list]);
}

public function  finishedList()
{
    $currentDate = Carbon::today();

    $finished_list =  DB::table('appoinments')
    ->select('appoinments.*', DB::raw('patients.name as patientname'))
    ->leftjoin('patients','appoinments.patient_id','=','patients.id')
    ->where('appoinments.status' , '=', "1")
    ->where('appoinments.date' , '=', $currentDate)
    ->where('patients.status' , '=', '0')
    ->get();

    return view('appointmentFinishedList',['finished_list' => $finished_list]);
}


public function finished(Request $request)

{

    $currentDate = Carbon::today();


    $date =  DB::table('appoinments')
        ->select('appoinments.date')
        ->where('appoinments.patient_id' , '=', $request->patient_id)
        ->where('appoinments.date' , '=', $currentDate)->first();
        $channel_date = $date->date;
        $data=[
        'patient_id' => $request->patient_id,
        'investigation_id' => $request->investigation_id,
        'treatment' => $request->treatment,
        'medicalTest' =>  $request->medicalTest,
        'next_visit_date' => $request->next_visit_date,
        'amount' => $request->amount,
        'comment' => $request->comment,
        'investigation_details' => $request->investigation_details,
        'channel_date' => $channel_date,
    ];

    InvestigationDetails::create($data);
    
    
$opdDrugs = $request->input('opdid');
    $doses = $request->input('opddose');
    $periods = $request->input('opdperiod');
    //dd($opdDrugs, $doses, $periods);
    // Loop through the data and save to the database using the Query Builder
    foreach ($opdDrugs as $key => $opdDrug) {
        DB::table('reccomanded_opd_drugs')->insert([
            'appointment_date' =>$currentDate,
            'patient_id' =>$request->patient_id,
            'drug' => $opdDrug,
            'dose' => $doses[$key],
            'period' => $periods[$key],
            // Add other fields as needed
        ]);

    }


$outsideDrugs = $request->input('outsideid');
    $outsidedose = $request->input('outsidedose');
    $outsideperiod = $request->input('outsideperiod');
    //dd($outsideDrugs, $doses, $periods);
    // Loop through the data and save to the database using the Query Builder
    foreach ($outsideDrugs as $key => $outDrug) {
        DB::table('reccomanded_outside_drugs')->insert([
            'appointment_date' =>$currentDate,
            'patient_id' =>$request->patient_id,
            'drug' => $outDrug,
            'dose' => $outsidedose[$key],
            'period' => $outsideperiod[$key],
            // Add other fields as needed
        ]);

    }

    // Get the data from the request
    $investi = $request->input('invid');

    // Loop through the data and save to the database using the Query Builder
    foreach ($investi as $key => $inves) {
        DB::table('investigation_history')->insert([
            'investtigation' => $inves,
            'patient_id' => $request->patient_id,
            'appointment_date' => $currentDate,
            // Add other fields as needed
        ]);
    }
    
    $meditest = $request->input('medid');

    // Loop through the data and save to the database using the Query Builder
    foreach ($meditest as $key => $medtest) {
        DB::table('medical_test')->insert([
            'medical_test' => $medtest,
            'patient_id' => $request->patient_id,
            'appointment_date' => $currentDate,
            // Add other fields as needed
        ]);
    }


$Appoinment = [
    'status' => 1
];

DB::table('appoinments')
    ->where('patient_id', $request->patient_id)
    ->where('date', $currentDate)
    ->update($Appoinment);



    $appoinments =  DB::table('appoinments')
    ->select('appoinments.*', DB::raw('patients.name as patientname'),DB::raw('patients.id as patientid'))
    ->leftjoin('patients','appoinments.patient_id','=','patients.id')
    ->where('appoinments.status' , '=', '0')
    ->where('appoinments.date' , '=', $currentDate)
    ->get();
    return view('doctorhome', ['appoinments' => $appoinments]);


try {
    return redirect()->back()->with('success', 'Appointment Finished Successfuly Updated ..!');

} catch (Exception $e) {

    return redirect()->back()->with('error', 'Appointment Finished Updated Error ..!');
}
}
}
