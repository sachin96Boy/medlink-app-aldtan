<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\DB;
use App\Models\Title;
use App\Models\Patients;


class PatientController extends Controller
{
    public function view()
    {

        $titles =  DB::table('titles')
        ->select('titles.*')
        ->get();

        $familyNames =  DB::table('patients')
        ->select('patients.family_name')
        ->groupBy('patients.family_name')
        ->get();


            return view('patientAddView',['titles' => $titles],['familyNames' => $familyNames]);


    }

    public function add(Request $request)
    {
		$data=[
                    'title' => $request->title,
                    'family_name' => $request->family_name,
                    'name' => $request->name,
                    'birthday' =>  $request->birthday,
                    'age' => $request->age,
                    'gender' => $request->gender,
                    'address' => $request->address,
                    'mobile' => $request->mobile,
                    'email' => $request->email,
                    'height_feets' => $request->height_feets,
                    'height_inches' => $request->height_inches,
                    'height_cen' => $request->height_cen,
                    'weight' => $request->weight,
                    'nic' => $request->nic,
                    'occupation' => $request->occupation,
                ];
                Patients::create($data);

                try {
                    return redirect()->back()->with('success', 'Patient Successfuly Saved ..!');

                } catch (Exception $e) {

                    return redirect()->back()->with('error', 'Patient Inserting Error ..!');
                }
}

 public function patient_list_search_by_family_name(Request $request)
    {


        $patient_list = DB::table('patients')
            ->join('titles', 'titles.id', '=', 'patients.title');

        if (isset($request->family_name)) {
            $family_name = $request->family_name;
            $patient_list =$patient_list->where("patients.family_name", $family_name );
        }
        $patient_list = $patient_list->where("patients.status", "=", "0")
            ->select('patients.*','titles.title as title')
            ->get();


        return view('patisentpopup',[ 'patient_list' => $patient_list , 'currentPatientId' => $request->currentPatientId]);

    }

    public function genReport(Request $request)
    {
        $id = $request->input('id');
        $patients =  DB::table('patients')
        ->select('patients.*', DB::raw('titles.id as title'))
        ->leftjoin('titles','patients.title','=','titles.id')
        ->where('patients.id' , '=', $id)
        ->get();
        $selectedValues = $request->input('selectedValues');
        $pageName = $request->input('pageName');


        return view('test',['selectedValues' => $selectedValues,'pageName' => $pageName,'patients' =>$patients]);
    }
public function patient_list_view()
    {

         $famname =  DB::table('patients')
        ->select('patients.family_name')
        ->groupBy('patients.family_name')
        ->get();


        $patient_list = DB::table('patients')
            ->join('titles', 'titles.id', '=', 'patients.title')
            ->where("patients.status", "=", "0")
            ->select('patients.*','titles.title as title')
            ->get();

        return view('patientListView',['famname' => $famname,'patient_list' => $patient_list]);

    }
    
    public function patient_list_search(Request $request)
    {

        $famname =  DB::table('patients')
        ->select('patients.family_name')
        ->groupBy('patients.family_name')
        ->get();

        $patient_list = DB::table('patients')
            ->join('titles', 'titles.id', '=', 'patients.title');

        if (isset($request->keyword)) {
            $keyword = $request->keyword;
            $patient_list =$patient_list->orwhere("patients.nic", 'LIKE', '%' . $keyword . '%');
            $patient_list =$patient_list->orwhere("patients.family_name", 'LIKE', '%' . $keyword . '%');
            $patient_list =$patient_list->orwhere("patients.name", 'LIKE', '%' . $keyword . '%');
            $patient_list =$patient_list->orwhere("patients.mobile", 'LIKE', '%' . $keyword . '%');
            $patient_list =$patient_list->orwhere("patients.address", 'LIKE', '%' . $keyword . '%');
        }

        $patient_list = $patient_list->where("patients.status", "=", "0")
            ->select('patients.*','titles.title as title')
            ->get();

        return view('patientListView',['famname' => $famname , 'patient_list' => $patient_list]);

    }

    public function edit_view($id)
    {

        $titles =  DB::table('titles')
        ->select('titles.*')
        ->get();



        $patients =  DB::table('patients')
        ->select('patients.*', DB::raw('titles.id as title'))
        ->leftjoin('titles','patients.title','=','titles.id')
        ->where('patients.id' , '=', $id)
        ->get();

         $famname =  DB::table('patients')
        ->select('patients.family_name')
        ->groupBy('patients.family_name')
        ->get();

        return view('patientEditView',['titles' => $titles ,'patients' => $patients, 'famname' => $famname]);
    }

    public function edit_viewtable($id)
    {

        $titles =  DB::table('titles')
        ->select('titles.*')
        ->get();

        $famname =  DB::table('patients')
        ->select('patients.family_name')
        ->groupBy('patients.family_name')
        ->get();

        $patients =  DB::table('patients')
        ->select('patients.*', DB::raw('titles.id as title'))
        ->join('titles','patients.title','=','titles.id')
        ->where('patients.id' , '=', $id)
        ->get();

        return view('patientEditViewTable', ['titles' => $titles, 'patients' => $patients, 'famname' => $famname]);
    }

    public function update(Request $request)

    {
        $Patients = Patients::find($request->id);
    $Patients->update([
        'title' => $request->title,
        'family_name' => $request->family_name,
        'name' => $request->name,
        'birthday' =>  $request->birthday,
        'age' => $request->age,
        'gender' => $request->gender,
        'address' => $request->address,
        'mobile' => $request->mobile,
        'email' => $request->email,
        'height_feets' => $request->height_feets,
        'height_inches' => $request->height_inches,
        'height_cen' => $request->height_cen,
        'weight' => $request->weight,
        'nic' => $request->nic,
        'occupation' => $request->occupation,
    ]);

    try {
        return redirect()->back()->with('success', 'Patient Successfuly Updated ..!');

    } catch (Exception $e) {

        return redirect()->back()->with('error', 'Patient Updated Error ..!');
    }
}

public function delete(Request $request){
    $Patients = Patients::find($request->id);
    $Patients->status='1';

    try {
        $Patients->save();
        return redirect()->back()->with('success', 'Patient Deleted ..!');

    } catch (Exception $e) {

        return redirect()->back()->with('error', 'Patient Deleted Error ..!');
    }
}

public function medicalhistory($id)
    {

        $patients =  DB::table('patients')
        ->select('patients.*')
        ->where('patients.id' , $id)
        ->get();

        $medicaltest = DB::table('medical_test')
            ->select('medical_test.*')
            ->where('medical_test.patient_id' , '=', $id)
            ->get();

        return view('medicalHistory',['medical_history' => $medicaltest,'patients' => $patients]);

  
    }
    
    public function investigationhistory($id)
    {
        $investigation_history = DB::table('investigation_history')
            ->select('investigation_history.*',)
            ->where('patient_id', $id)
            ->orderBy('appointment_date')
            ->get();

            $patients =  DB::table('patients')
            ->select('patients.*')
            ->where('patients.id' , $id)
            ->get();
        return view('investigationHistory',['investigation_history' => $investigation_history,'patients' => $patients]);

    }


public function investigation_history($id)
    {
      
        $patients =  DB::table('patients')
        ->select('patients.*')
        ->where('patients.id' , $id)
        ->get();
        $investigation_history = DB::table('investigation_history')
            ->select('investigation_history.*',)
        ->where('patient_id', $id)
        ->get();
      return view('investigation_history',['investigation_history' => $investigation_history,'patients' => $patients]);

    }


}


 



